	<!-- Header File -->
	
	<!-- Load External Font -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:500,600,700' rel='stylesheet' type='text/css'>
	
	<!-- Load General CSS File -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public_assests/css/style.css">
	
	<!-- Load Icons CSS File -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public_assests/css/font-awesome.css">

	<!-- Main Footer -->
	<div id='tag'>
		<h1 id="Main">
			Shopping Cart System
		</h1>
	</div>
	
	<!-- Main Menu -->
<div class="navbar navbar-fixed-top scroll-hide" style="overflow: visible;">


    <div class="container-fluid main-nav clearfix">
        <div class="nav-collapse">
            <ul class="nav">
                <li>
                    <a id="home" class="menu current" href="<?php echo base_url(); ?>">
					<span aria-hidden="true" class="icon-home"></span>Home</a>
                </li>

				<li>
					<a id="request" href="<?php echo base_url()?>/Products" class="menu">
					<span aria-hidden="true" class="icon-file-text-alt"></span>Products</a> 
				</li>

			
				<li>
					<a class="menu" href="<?php echo base_url(); ?>/Users">
					<span aria-hidden="true" class="icon-key"></span>Users</a>
				</li>
				
				<li>
					<a id="card" href="<?php echo base_url(); ?>Reports" class="menu">
					<span aria-hidden="true" class="icon-list-alt"></span>Reports</a>
				</li>
            </ul>
        </div>
    </div>
</div>