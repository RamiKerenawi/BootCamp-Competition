
		
       <div id='result_div'>
            <?php
            // this will show you thank you message.
            echo "<h1 align='center'>Thank You! your order has been placed!</h1>";
            echo "<span id='go_back'><a class='fg-button teal' href=" . base_url() . "index.php/shopping>Go back</a></span>";
            ?>
        </div>
